const events = new EventTarget()
export default events
